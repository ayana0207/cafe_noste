      <footer class="l_footer">
        <div class="l_footer_contents">
          <div class="l_footer_info">
            <!-- aタグ＆imgタグ　エスケープ処理と絶対パス記述 -->
            <a href="<?php echo esc_url(home_url()); ?>" class="l_footer_info-logo">
              <img
                src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/logo_01.webp' ); ?>"               
                alt="ノステのロゴ"
                width="132"
                height="60"
                class="l_footer_info-logo__img"
              />
            </a>
            <div class="l_footer_info-icon__box">
              <div class="l_footer_info-icon__block">
                <a
                  href="https://about.instagram.com/ja-jp"
                  class="l_footer_info-icon"
                >
                <!-- img記述 -->
                  <img
                    src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/icon_Instagram.webp' ); ?>"
                    alt="インスタグラムのアイコン"
                    width="40"
                    height="40"
                    class="footer_info-icon__insta"
                  />
                </a>
              </div>
              <div class="l_footer_info-icon__block">
                <a 
                  href="https://x.com/xcorpjp" 
                  class="l_footer_info-icon"
                  >
                <!-- img記述 -->
                  <img
                    src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/icon_x.webp' ); ?>"
                    alt="Xのアイコン"
                    width="40"
                    height="40"
                    class="footer_info-icon__x"
                  />
                </a>
              </div>
            </div>
          </div>
          <p class="l_footer-copyright">
            <small class="l_footer-copyright_txt">&copy; 2025 Noste</small>
          </p>
        </div>
      </footer>
      <!-- フッター -->
    </main>

    <!-- ワードプレスフッター動作タグ -->
    <?php wp_footer(); ?>
  </body>
</html>
