<?php /* template-parts/section-contact.php */ ?>
<section id="contact" class="top_contact-section js_link-page">
  <div class="top_contact-ttl_group">
    <h2 class="top_contact-ttl">
      お問い合わせ
      <!-- <a name="contact">お問い合わせ</a> -->
    </h2>
    <p class="top_contact-txt">
      雑誌やメディアの取材も受け付けております。こちらからお気軽にお問い合わせください。
    </p>
  </div>
  <div class="contact_form">
    <?php
      // CF7 の “数値ID” に必ず置き換えてください（例: 123）
      echo do_shortcode('[contact-form-7 id="9" title="問い合わせ"]');
    ?>
  </div>
</section>


<!-- <section class="top_contact-section">
        <div class="top_contact-ttl_group">
          <h2 class="top_contact-ttl">
            <a name="contact">お問い合わせ</a>
          </h2>
          <p class="top_contact-txt">
            雑誌やメディアの取材も受け付けております。こちらからお気軽にお問い合わせください。
          </p>
        </div>
        <div action="" class="contact_form"> -->
        <!-- ワードプレスに貼り付け後formタグ含めコメントアウト -->
        <!-- <form action="" class="contact_form">
          <dl class="contact_form_list">
            <dt class="contact_form_heading">
              お名前
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input type="text" class="contact_form_input" required />
            </dd>
            <dt class="contact_form_heading">
              会社名
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input type="text" class="contact_form_input" required />
            </dd>
            <div class="contact_form_example-wrapper">
              <span class="contact_form_example">
                正式名称にてご記入ください。個人の方は「個人」とご記入ください。
              </span>
            </div>
            <dt class="contact_form_heading">
              メールアドレス
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input
                type="email"
                placeholder="example@example.com"
                class="contact_form_input"
                required
              />
            </dd>
            <dt class="contact_form_heading">
              電話番号
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input
                type="tel"
                pattern="[0-9]{3}-[0-9]{4}-[0-9]{4}"
                class="contact_form_input"
                required
              />
            </dd>
            <dt class="contact_form_heading">
              お問い合わせ内容
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <textarea
                rows="8"
                name=""
                id=""
                class="contact_form_textarea"
                required
              ></textarea>
            </dd>
          </dl>
          <div class="contact_form_btn-wrapper">
            <input
              type="submit"
              class="contact_form_btn"
              value="メッセージを送信する"
            />
          </div>
        </form> -->
        <!-- </div>
      </section> -->