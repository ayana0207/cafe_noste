<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Cafe Nosté</title>
    <meta
      name="description"
      content="こだわりのハンドドリップコーヒーをくつろぎの空間で。"
    />
    <meta name="format-detection" content="telephone=no" />

    <!-- favicon/web-clip-icon -->
    <link rel="icon" href="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/favicon.webp' ); ?>" type="image/ico" />
    <!-- <link rel="icon" href="favicon.png" type="image/png" /> -->
    <!-- <link rel="icon" href="favicon.svg" type="image/svg+xml" /> -->
    <link rel="apple-touch-icon" href="webclip.png" />

    <!-- ogp -->
    <meta property="og:site_name" content="Cafe & Moments Noste" />
    <meta
      property="og:url"
      content="https://student.zero-plus-test.xyz/production/02-28/WebP/cafeNoste_OGP.webp"      
      />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Cafe Nosté" />
    <meta
      property="og:description"
      content="こだわりのハンドドリップコーヒーをくつろぎの空間で。"
    />
    <meta
      property="og:image"
      content="https://student.zero-plus-test.xyz/production/02-28/WebP/cafeNoste_OGP.webp"
    />
    <meta property="og:locale" content="ja_JP" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta
      name="twitter:description"
      content="こだわりのハンドドリップコーヒーをくつろぎの空間で。"
    />
    <meta
      name="twitter:image:src"
      content="https://student.zero-plus-test.xyz/production/02-28/WebP/cafeNoste_OGP.webp"
    />

    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Serif+JP:wght@200..900&display=swap"
      rel="stylesheet"
    />

    <!-- css -->
    <link rel="stylesheet" href="css/reset.css" />
    <!-- リセットCSSのすぐ下にスワイパー -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="css/style.css" />
    <!-- GSAP スクロールトリガー スワイパー & js -->
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/gsap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/ScrollTrigger.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/ScrollToPlugin.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.js"></script>
    <script src="js/main.js" defer></script>

    <!-- ワードプレス　ヘッダー動作タグ記述 -->
    <?php wp_head(); ?>
  </head>

  <body class="js_body js_opening-body">
    <div class="m_opening js_opening">
      <div class="m_opening-img_block">
        <div class="m_opening-img_box js_opening-img">
          <img 
          src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/logo_01.webp' ); ?>"
          alt="カフェのロゴ"
          width="132"
          height="60"
          class="m_opening-img"
          >
        </div>
      </div>
    </div>
    <header class="l_header js_link-page" id="top">
      <h1 class="l_header-logo">
        <!-- aタグ＆imgタグ　エスケープ処理と絶対パス記述 -->
        <a href="<?php echo esc_url(home_url()); ?>" class="l_header-logo_link">
          <img
            src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/logo_01.webp' ); ?>"
            alt="カフェのロゴ"
            width="132"
            height="60"
            class="l_header-logo_img"
          />
        </a>
      </h1>
      <nav class="l_header-nav js_nav">
        <ul class="l_header-nav_list">
          <!-- aタグ＆imgタグ　エスケープ処理と絶対パス記述 -->
          <li class="l_header-nav_item">
            <a href="#top" class="l_header-nav_link">Top</a>
          </li>
          <li class="l_header-nav_item">
            <a href="#about" class="l_header-nav_link">About</a>
          </li>
          <li class="l_header-nav_item">
            <a href="#commitment" class="l_header-nav_link">こだわり</a>
          </li>
          <li class="l_header-nav_item">
            <a href="#menu" class="l_header-nav_link">Menu</a>
          </li>
          <li class="l_header-nav_item">
            <a href="#address" class="l_header-nav_link">Address</a>
          </li>
          <li class="l_header-nav_item">
            <a href="#contact" class="l_header-nav_link">Contact</a>
          </li>
          <li class="l_header-nav_item">
            <!-- 外部リンクはそのまま　img部分を記述 -->
            <a
              href="https://about.instagram.com/ja-jp"
              class="l_header-nav_link"
            >
              <img
                src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/icon_Instagram.webp' ); ?>"
                alt="Instagram"
                width="40"
                height="40"
                class="l_header-nav_img"
              />
            </a>
          </li>
        </ul>
      </nav>
      <!-- ヘッダー -->
      <button class="m_hamburger js_hamburger">
        <span class="m_hamburger-bar"></span>
        <span class="m_hamburger-bar"></span>
        <span class="m_hamburger-bar"></span>
      </button>
      <!-- ハンバーガーメニュー -->
    </header>