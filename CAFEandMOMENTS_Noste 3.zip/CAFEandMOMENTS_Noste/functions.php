<?php 
  // cssの読み込み
add_action('wp_enqueue_scripts', 'add_styles');

function add_styles() {
  // google fonts
  wp_enqueue_style('google-fonts_style', 'https://fonts.googleapis.com/css2?family=Noto+Serif+JP:wght@200..900&display=swap');

  // reset style
  wp_register_style(
    'reset_style', // 登録する識別名
    get_template_directory_uri() . '/src/css/reset.css', // 登録するCSSのパス
    array(), // CSSの依存先
    '1.0' // パラメータの付与（スタイルの変更に合わせて変更することで、キャッシュを防ぐことができる）
  );

  // swiper style
  wp_register_style(
    'swiper_style',
    'https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css',
    array(),
    '1.0'
  );

  // main style
  wp_enqueue_style(
    'main_style',
    get_theme_file_uri() . '/src/css/style.css',
    // get_template_directory_uri() . '/src/css/style.css',
    array('reset_style', 'swiper_style'),
    '1.0'
  );

  // jsの読み込み（合っているか確認!!）
  wp_enqueue_script(
    'common_script',
    get_template_directory_uri() . '/src/js/main.js',
    array(),
    false,
    true
  );
}

// Contact Form 7で自動挿入されるPタグ、brタグを削除
add_filter('wpcf7_autop_or_not', 'wpcf7_autop_return_false');
function wpcf7_autop_return_false() {
  return false;
}

// アイキャッチ（＝Featured Image／サムネイル画像）を使用する
add_theme_support( 'post-thumbnails' );
?>