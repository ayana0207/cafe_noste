<!-- ヘッダーの呼び出し記述 -->
<?php get_header(); ?>

    <!-- キービジュアル -->
    <div class="top_kv">
      <div class="top_kv_inner">
        <div class="top_kv_box">
          <p class="top_kv_copy js_copy">心の休息を<br />この空間で。</p>
        </div>
      </div>
    </div>
    <!-- TOP KV スライドショー -->
    <div class="top_kv-slideshow swiper js_slideshow">
      <div class="swiper-wrapper">
        <div class="top_kv-slideshow_slide swiper-slide">
          <img 
          src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_top.webp' ); ?>" 
          alt="カフェ店内の写真" 
          width="3762"
          height="2581"
          class="top_kv-slideshow_slide_img">
        </div>
        <div class="top_kv-slideshow_slide swiper-slide">
          <img 
          src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_top_02.webp' ); ?>" 
          alt="カフェ店内の写真" 
          width="1280"
          height="947"
          class="top_kv-slideshow_slide_img">
        </div>
        <div class="top_kv-slideshow_slide swiper-slide">
          <img 
          src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_top_03.webp' ); ?>" 
          alt="ラテアートの写真" 
          width="1280"
          height="855"
          class="top_kv-slideshow_slide_img">
        </div>
      </div>
    </div>
    <!-- top_kv終わり -->
    <!-- aboutセクション -->
    <main class="l_main">
      <section id="about" class="top_about-section js_link-page">
        <div class="top_about-wrapper">
          <div class="top_about_contents">
            <!-- 見せ窓「js-parallax-elm-box」 -->
            <div class="top_about_main-img_box js-parallax-elm-box">
              <!-- 動かす要素「js-parallax-elm」 -->
              <div class="js-parallax-elm">
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_about_01.webp' ); ?>"
                  alt="Nosté店主の写真"
                  width="1280"
                  height="853"
                  class="top_about_main-img js_img-fadein"
                />
              </div>
            </div>
            <div class="top_about-main_box">
              <h2 class="top_about_ttl">
                Nostéの想い
                <!-- <a name="about">Nostéの想い</a> -->
                </h2>
              <p class="top_about_txt">
                〜Nosté（ノステ）〜とは「Nostalgia」と「Nouveau」を掛け合わせた造語です。<br />
                どこか懐かしさを感じつつも時代とともに新しい挑戦を続けていきたい、そんな私たちの想いがこもっています。
              </p>
            </div>
          </div>
          <div class="top_about_sub-img__block">
            <div class="top_about_sub-img__box js-parallax-elm-box">
              <div class="js-parallax-elm">
                <img 
                src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_about_07.webp' ); ?>" 
                alt="コーヒーの写真" 
                width="760"
                height="800"
                class="top_about_sub-img js_img-fadein"
                >
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- aboutセクション終わり -->
      <!-- こだわりセクション -->
      <section id="commitment" class="top_commitment-section js-scroll-overlap js_link-page">
        <div class="top_commitment_contents">
          <div class="top_commitment_block coffee">
            <div class="top_commitment-img_box coffee">
              <!-- <div class="js-parallax-elm"> -->
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_about_03.webp' ); ?>"
                  alt="コーヒーを煎る画像"
                  width="1280"
                  height="853"
                  class="top_commitment-img coffee js_img-fadein"
                />
              <!-- </div> -->
            </div>
            <div class="top_commitment-txt_box coffee">
              <h3 class="m_commitment_ttl">
                コーヒー豆へのこだわり
                <!-- <a name="commitment">コーヒー豆へのこだわり</a> -->
              </h3>
              <p class="m_commitment_txt">
                使用しているのは全てフェアトレードのコーヒー豆。<br />
                生産者の皆様が誇りを持って育て上げたこの一粒を私たちの手で丁寧に淹れ、お客様のもとへお届けする。<br /><br />
                「生産者も飲む人もみんなが笑顔になれる一杯を」<br /><br />
                ゆっくりと立ちのぼる湯気の向こうに、そんな物語を感じていただけたら嬉しいです。
              </p>
            </div>
          </div>
          <div class="top_commitment_block hand">
            <div class="top_commitment-img_box hand js_img-fadein">
              <!-- <div class="js-parallax-elm"> -->
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_about_04.webp' ); ?>"
                  alt="店主がコーヒーを入れる画像"
                  width="640"
                  height="427"
                  class="top_commitment-img hand"
                />
              <!-- </div> -->
            </div>
            <div class="top_commitment-txt_box hand">
              <h3 class="m_commitment_ttl">ハンドドリップへのこだわり</h3>
              <p class="m_commitment_txt">
                豆の状態、湿度、温度、抽出時間<br />
                その日、その時、の条件に合わせて毎朝焙煎度や挽き方、蒸らしの時間を見極めています。<br /><br />
                流れるお湯の音、ふわりと立ちのぼる香り、カップに注がれるその一滴まで全神経を注ぐ時間。
                それは効率とは遠く離れた行為かもしれませんが、だからこそ味わえる深みと余韻がそこにあると信じています。<br /><br />
                ひと息つきたい日やなんとなく心を整えたい時には、この一杯がそっと寄り添ってくれるはずです。
              </p>
            </div>
          </div>
          <div class="top_commitment_block space">
            <div class="top_commitment-img_box space">
              <!-- <div class="js-parallax-elm"> -->
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_about_06.webp' ); ?>"
                  alt="店内の画像"
                  width="3012"
                  height="2008"
                  class="top_commitment-img space js_img-fadein"
                />
              <!-- </div> -->
            </div>
            <div class="top_commitment-txt_box space">
              <h3 class="m_commitment_ttl">空間へのこだわり</h3>
              <p class="m_commitment_txt">
                都会の静かな路地に佇むNostéは、老舗喫茶店のような確かな味わいと、都会の中にひっそりと息づく安らぎを大切にしています。<br /><br />
                店内は席同士にゆとりをもたせており、周りを気にせずに自分の時間に集中できるような空間です。
                無料Wi-Fiも完備しておりちょっとした打ち合わせやノートパソコンでの作業にもご活用いただけます。<br /><br />
                日々の慌ただしさの中でふと立ち止まりたくなったときに、思い出していただける場所でありたいと願っています。
              </p>
            </div>
          </div>
        </div>
      </section>
      <!-- こだわりセクション終わり -->
      <!-- セクション間画像 -->
      <section class="top_image-section">
        <div class="m_image-box js-parallax-elm-box">
          <!-- 動かす要素「js-parallax-elm」 -->
          <div class="js-parallax-elm">
            <img
              src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_coffee_01.webp' ); ?>"
              alt="コーヒーカップの画像"
              width="1280"
              height="853"
              class="m_image-img coffee_top"
            />
          </div>
        </div>
      </section>
      <!-- セクション間の画像終わり -->
      <!-- ランチメニューセクション -->
      <section id="menu" class="m_menu-section lunch js_link-page">
        <div class="m_menu_contents lunch">
          <div class="m_menu-copy_box">
            <h3 class="m_menu-copy_ttl">
              ランチセット
              <!-- <a name="menu">ランチセット</a> -->
            </h3>
            <p class="m_menu-copy_sub-ttl">（Lunch time 11:00~14：00）</p>
            <p class="m_menu-copy_sub-txt">
              ミニサラダ＆ドリンク付き（ドリンクメニューよりお好きなドリンクが選べます）
              <br />
              ランチセットはすべて1,200円です
            </p>
          </div>
          <div class="m_menu-group__lunch js_slide-trigger">
            <!-- ここからワードプレスで投稿したドリンクメニューを反映するコードに移る -->
            <?php
              // ACFグループ「menu」のサブフィールド「category」は meta_key が「menu_category」になる
              $lunch_query = new WP_Query([
                'post_type' => 'post',    
                // もしカスタム投稿タイプならここを 'menu' などに変更
                'posts_per_page' => -1,
                // -1はすべて取得という意味
                'orderby' => 'date',
                // 公開日順
                'order' => 'DESC',
                // 表示順はお好みで。新しい順'DESC'古い順'ASC'
                'meta_query' => [
                  [
                  'key' => 'menu_category', 
                  // ← ACFグループ(menu)のサブフィールドcategory
                  'value' => 'ランチ',
                  'compare' => '='
                  // 取得するのは'value'と完全一致の場合のみ
                  ],
                ],
              ]);
              if ( $lunch_query -> have_posts() ) :
                while ( $lunch_query -> have_posts() ) : $lunch_query -> the_post();
                $menu = get_field('menu'); 
                // ['price'], ['description'] などを取得
            ?>
            <div class="m_menu_box js_slide">
              <div class="m_menu_img__block">
                <!-- この投稿のアイキャッチ画像を出力 -->
                <?php the_post_thumbnail(null, array('class' => 'm_menu_img')); ?>
              </div>
              <p class="m_menu_ttl">
                <?php the_title(); ?>
              </p>
              <p class="m_menu_price__lunch">
                ¥<?php echo esc_html($menu['price']); ?>-
              </p>
              <p class="m_menu_txt__lunch">
                <?php echo esc_html($menu['description']); ?>
              </p>
            </div>
            <?php
              endwhile;
              wp_reset_postdata(); // ★ メインクエリを汚さないために必須
              else:
              echo '<p>Coming soon!</p>';
              endif;
            ?>
          </div>
        </div>
      </section>
      <!-- ランチメニューセクション終わり -->
      <!-- ドリンクメニューセクション -->
      <section class="m_menu-section drink">
        <div class="m_menu_contents">
          <div class="m_menu_container">
            <div class="m_menu-copy_box">
              <h3 class="m_menu-copy_ttl">ドリンクメニュー</h3>
            </div>
            <div class="m_menu-group js_slide-trigger">
              <!-- ここからワードプレスで投稿したドリンクメニューを反映するコードに移る -->
              <?php
                // ACFグループ「menu」のサブフィールド「category」は meta_key が「menu_category」になる
                $drink_query = new WP_Query([
                  'post_type' => 'post',    
                  // もしカスタム投稿タイプならここを 'menu' などに変更
                  'posts_per_page' => 9,
                  // -1はすべて取得という意味
                  'orderby' => 'date',
                  // 公開日順
                  'order' => 'DESC',
                  // 表示順はお好みで。新しい順'DESC'古い順'ASC'
                  'meta_query' => [
                    [
                    'key' => 'menu_category', 
                    // ← ACFグループ(menu)のサブフィールドcategory
                    'value' => 'ドリンク',
                    'compare' => '='
                    // 取得するのは'value'と完全一致の場合のみ
                    ],
                  ],
                ]);
                if ( $drink_query -> have_posts() ) :
                  while ( $drink_query -> have_posts() ) : $drink_query -> the_post();
                  $menu = get_field('menu'); 
                  // ['price'], ['description'] などを取得
              ?>
              <div class="m_menu_box js_slide">
                <div class="m_menu_img__block">
                  <!-- この投稿のアイキャッチ画像を出力 -->
                  <?php the_post_thumbnail(null, array('class' => 'm_menu_img')); ?>
                </div>
                <p class="m_menu_ttl">
                  <?php the_title(); ?>
                </p>
                <p class="m_menu_price">
                  ¥<?php echo esc_html($menu['price']); ?>-
                </p>
                <p class="m_menu_txt">
                  <?php echo esc_html($menu['description']); ?>
                </p>
              </div>
              <?php
                endwhile;
                wp_reset_postdata(); // ★ メインクエリを汚さないために必須
                else:
                echo '<p>Coming soon!</p>';
                endif;
              ?>
            </div>
          </div>
        </div>
      </section>
      <!-- ドリンクメニューセクション終わり -->
      <!-- フードメニューセクション -->
      <section class="m_menu-section food js-scroll-overlap">
        <div class="m_menu_contents">
          <div class="m_menu_container">
            <div class="m_menu-copy_box">
              <h3 class="m_menu-copy_ttl">フードメニュー</h3>
            </div>
            <div class="m_menu-group js_slide-trigger">
              <!-- ここからワードプレスで投稿したフードメニューを反映するコードに移る -->
              <?php
                // ACFグループ「menu」のサブフィールド「category」は meta_key が「menu_category」になる
                $food_query = new WP_Query([
                  'post_type' => 'post',    
                  // もしカスタム投稿タイプならここを 'menu' などに変更
                  'posts_per_page' => 6,
                  // -1はすべて取得という意味
                  'orderby' => 'date',
                  // 公開日順
                  'order' => 'DESC',
                  // 表示順はお好みで。新しい順'DESC'古い順'ASC'
                  'meta_query' => [
                    [
                    'key' => 'menu_category', 
                    // ← ACFグループ(menu)のサブフィールドcategory
                    'value' => 'フード',
                    'compare' => '='
                    // 取得するのは'value'と完全一致の場合のみ
                    ],
                  ],
                ]);
                if ( $food_query -> have_posts() ) :
                  while ( $food_query -> have_posts() ) : $food_query -> the_post();
                  $menu = get_field('menu'); 
                  // ['price'], ['description'] などを取得
              ?>

              <div class="m_menu_box js_slide">
                <div class="m_menu_img__block">
                  <!-- この投稿のアイキャッチ画像を出力 -->
                  <?php the_post_thumbnail(null, array('class' => 'm_menu_img')); ?>
                </div>
                <p class="m_menu_ttl">
                  <?php the_title(); ?>
                </p>
                <p class="m_menu_price">
                  ¥<?php echo esc_html($menu['price']); ?>-
                </p>
                <p class="m_menu_txt">
                  <?php echo esc_html($menu['description']); ?>
                </p>
              </div>

              <?php
                endwhile;
                wp_reset_postdata(); // ★ メインクエリを汚さないために必須
                else:
                echo '<p>Coming soon!</p>';
                endif;
              ?>
            </div>
          </div>
        </div>
      </section>
      <!-- フードメニューセクション終わり -->
      <!-- セクション間の画像 -->
      <section class="top_image-section">
        <div class="m_image-box js-parallax-elm-box">
          <!-- 動かす要素「js-parallax-elm」 -->
          <div class="js-parallax-elm">
            <img
              src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_coffee_01.webp' ); ?>"
              alt="コーヒーカップの画像"
              width="1280"
              height="853"
              class="m_image-img coffee_bottom"
            />
          </div>
        </div>
      </section>
      <!-- セクション間の画像終わり -->
      <!-- アドレスセクション -->
      <section id="address" class="top_address-section js-scroll-overlap js_link-page">
        <div class="top_address_contents">
          <h2 class="top_address_ttl">
            店舗情報
            <!-- <a name="address">店舗情報</a> -->
          </h2>
        </div>
        <div class="top_address_group">
          <div class="top_address-img_box">
            <div class="top_address-img_block js-parallax-elm-box">
              <!-- 動かす要素「js-parallax-elm」 -->
              <div class="js-parallax-elm">
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/address_1.webp' ); ?>"
                  alt="店内の画像"
                  width="3024"
                  height="4032"
                  class="top_address-img__left"
                />
              </div>
            </div>
            <div class="top_address-img_block js-parallax-elm-box">
              <!-- 動かす要素「js-parallax-elm」 -->
              <div class="js-parallax-elm">
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/address_2.webp' ); ?>"
                  alt="店内の画像"
                  width="3024"
                  height="4032"
                  class="top_address-img__center"
                />
              </div>
            </div>
            <div class="top_address-img_block js-parallax-elm-box">
              <!-- 動かす要素「js-parallax-elm」 -->
              <div class="js-parallax-elm">
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/address_3.webp' ); ?>"
                  alt="店内の画像"
                  width="3024"
                  height="4032"
                  class="top_address-img__right"
                />
              </div>
            </div>
          </div>
          <div class="top_address-data_box">
            <div class="top_address-data_ttl__box">
              <div class="top_address-data_ttl__block noste">
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/logo_02.webp' ); ?>"
                  alt="Nosteのロゴ"
                  width="155"
                  height="47"
                  class="top_address-data_ttl__img"
                />
              </div>
              <div class="top_address-data_ttl__block cafe">
                <img
                  src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/logo_03.webp' ); ?>"
                  alt="Nosteのロゴ"
                  width="135"
                  height="16"
                  class="top_address-data_ttl__img"
                />
              </div>
            </div>
            <table class="top_address-data_table">
              <tr class="top_address-data_tr">
                <th class="top_address-data_th">住所</th>
                <td class="top_address-data_td">東京都渋谷区神宮前3丁目1-25</td>
              </tr>
              <tr class="top_address-data_tr">
                <th class="top_address-data_th">電話番号</th>
                <td class="top_address-data_td">000-0000-0000</td>
              </tr>
              <tr class="top_address-data_tr">
                <th class="top_address-data_th">メールアドレス</th>
                <td class="top_address-data_td">hoge@cafe.jp</td>
              </tr>
              <tr class="top_address-data_tr">
                <th class="top_address-data_th">営業時間</th>
                <td class="top_address-data_td">
                  平日　8:00~20:00 <br />土・祝　8:00~17:00
                  <br />ラストオーダー閉店30分前まで
                </td>
              </tr>
              <tr class="top_address-data_tr">
                <th class="top_address-data_th">定休日</th>
                <td class="top_address-data_td">日曜日</td>
              </tr>
              <tr class="top_address-data_tr">
                <th class="top_address-data_th">東京メトロ</th>
                <td class="top_address-data_td">
                  千代田線　表参道駅A2出口から徒歩10分
                  <br />
                  銀座線　外苑前駅3番出口から徒歩8分
                </td>
              </tr>
            </table>
            <div class="top_address-data_txt__box">
              <div class="top_address-data_txt">
                最新情報は各SNSをご覧ください。
              </div>
              <div class="top_address-data_icon__box">
                <div class="top_address-data_icon__block">
                  <a
                    href="https://about.instagram.com/ja-jp"
                    class="top_address-data_icon__link"
                  >
                    <img
                      src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/icon_Instagram.webp' ); ?>"
                      alt="インスタのアイコン"
                      width="40"
                      height="40"
                      class="top_address-data_icon__insta"
                    />
                  </a>
                </div>
                <div class="top_address-data_icon__block">
                  <a
                    href="https://x.com/xcorpjp"
                    class="top_address-data_icon__link"
                  >
                    <img
                      src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/icon_x.webp' ); ?>"
                      alt="Xのアイコン"
                      width="40"
                      height="40"
                      class="top_address-data_icon__x"
                    />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="top_address__map">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3241.2857476839217!2d139.71137767618927!3d35.669965430592!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188c98d6802ff5%3A0x407195664c18030!2z44CSMTUwLTAwMDEg5p2x5Lqs6YO95riL6LC35Yy656We5a6u5YmN77yT5LiB55uu77yR4oiS77yS77yVIOOCs-ODvOODneWkluiLkeOCteOCpOODiQ!5e0!3m2!1sja!2sjp!4v1758125962974!5m2!1sja!2sjp"
            width="600"
            height="450"
            style="border: 0"
            allowfullscreen=""
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          >
          </iframe>
        </div>
      </section>
      <!-- アドレスセクション終わり -->
      <section class="top_image-section">
        <div class="m_image-box js-parallax-elm-box">
          <!-- 動かす要素「js-parallax-elm」 -->
          <div class="js-parallax-elm">
            <img
              src="<?php echo esc_url( get_template_directory_uri() . '/src/WebP/img_coffee_02.webp' ); ?>"
              alt="コーヒーカップの画像"
              width="1280"
              height="853"
              class="m_image-img coffee_bottom"
            />
          </div>
        </div>
      </section>
      <!-- セクション間の画像 -->
      <!-- お問い合わせセクションがあったところ お問い合わせの呼び出し-->
      <?php get_template_part('template-parts/section-contact'); ?>
      <!-- <section class="top_contact-section">
        <div class="top_contact-ttl_group">
          <h2 class="top_contact-ttl">
            <a name="contact">お問い合わせ</a>
          </h2>
          <p class="top_contact-txt">
            雑誌やメディアの取材も受け付けております。こちらからお気軽にお問い合わせください。
          </p>
        </div>
        <form action="" class="contact_form">
          <dl class="contact_form_list">
            <dt class="contact_form_heading">
              お名前
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input type="text" class="contact_form_input" required />
            </dd>
            <dt class="contact_form_heading">
              会社名
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input type="text" class="contact_form_input" required />
            </dd>
            <div class="contact_form_example-wrapper">
              <span class="contact_form_example">
                正式名称にてご記入ください。個人の方は「個人」とご記入ください。
              </span>
            </div>
            <dt class="contact_form_heading">
              メールアドレス
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input
                type="email"
                placeholder="example@example.com"
                class="contact_form_input"
                required
              />
            </dd>
            <dt class="contact_form_heading">
              電話番号
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <input
                type="tel"
                pattern="[0-9]{3}-[0-9]{4}-[0-9]{4}"
                class="contact_form_input"
                required
              />
            </dd>
            <dt class="contact_form_heading">
              お問い合わせ内容
              <span class="contact_form_required">必須</span>
            </dt>
            <dd class="contact_form_detail">
              <textarea
                rows="8"
                name=""
                id=""
                class="contact_form_textarea"
                required
              ></textarea>
            </dd>
          </dl>
          <div class="contact_form_btn-wrapper">
            <input
              type="submit"
              class="contact_form_btn"
              value="メッセージを送信する"
            />
          </div>
        </form>
      </section> -->
      <!-- お問い合わせセクション -->
      
      <!-- フッターの呼び出し -->
      <?php get_footer(); ?>